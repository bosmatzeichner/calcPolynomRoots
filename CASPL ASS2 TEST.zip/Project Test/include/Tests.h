#ifndef TESTS_H_
#define TESTS_H_

#include <vector>
#include <complex>
#include <string>

using std::string;
using std::vector;
using std::complex;

// Declaring Functions
void InitializingTests();
bool retrieveProgramInput(string fileName, double & epsilon, vector<complex<double>> & coefficients);
complex<double> calculateComplexFunction(vector<complex<double>> coefficients,complex<double> z);
bool procceseTest(string testFile);
complex<double> retrieveRootProgramOutputComplex(string programOutput);
void INPUT_ONE_TEST();
void INPUT_TWO_TEST();
void INPUT_THREE_TEST();
void INPUT_FOUR_TEST();
void INPUT_FIVE_TEST();
void INPUT_SIX_TEST();
void INPUT_SEVEN_TEST();
void INPUT_EIGHT_TEST();
void INPUT_NINE_TEST();
void INPUT_TEN_TEST();
#endif
