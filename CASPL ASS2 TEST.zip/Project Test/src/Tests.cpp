#include "../include/Tests.h"
#include "../include/ProjectTest.h"
#include <iostream>
#include <typeinfo>
#include <fstream>
#include <complex>
#include <math.h>

using std::to_string;
using std::cout;
using std::sprintf;
using std::complex;

// Initializing tests to be executed
void InitializingTests()
{
    /* ### Example of use ###

     testsFunctions.push_back();

    */

    // Initializing tests to be executed
    testsFunctions.push_back(INPUT_ONE_TEST);
    testsFunctions.push_back(INPUT_TWO_TEST);
    testsFunctions.push_back(INPUT_THREE_TEST);
    testsFunctions.push_back(INPUT_FOUR_TEST);
    testsFunctions.push_back(INPUT_FIVE_TEST);
    testsFunctions.push_back(INPUT_SIX_TEST);
    testsFunctions.push_back(INPUT_SEVEN_TEST);
    testsFunctions.push_back(INPUT_EIGHT_TEST);
    testsFunctions.push_back(INPUT_NINE_TEST);
    testsFunctions.push_back(INPUT_TEN_TEST);
}

/* ### Example of use ###

// Executing DEMO_TEST
void DEMO_TEST()
{
  // Initializing
  currentTestName = DEMO_TEST

  // Testing

  test(0,"got","expected");

  try
  {
    test(1,"maybe exception will be thrwon from here,"$$$ ASSERT_THROWN_EXCEPTIONS $$$");
  }
  catch (ExceptionType exp)
  {
    test("","$$$ DECLARE GOOD TEST $$$");
  }

}
*/

// Retrieving program input
bool retrieveProgramInput(string fileName, double & epsilon, vector<complex<double>> & coefficients){
    // Initializing
    long order;

    // Opening input file
    FILE *input = fopen(fileName.c_str(),"r");
    if (input == NULL) {
        perror("Failed: ");
        test(0,"","$$$ DECLARE BAD TEST $$$");
        return 1;
    }


    // Retrieving epsilon and order from input
    fscanf(input,"%*7s%*1s%lf",&epsilon);
    fscanf(input,"%*5s%*1s%ld",&order);

    // Initializing coefficients array of size order + 1
    coefficients = vector<complex<double>>(order + 1);

    for(int i = 0; i < (order + 1);i++){
        // Initializing for current coefficient retrieval
        double realPart;
        double imaginaryPart;
        long currentOrder;

        // Retrieving current coefficient data
        fscanf(input,"%*5s%ld%*1s%lf%lf",&currentOrder,&realPart,&imaginaryPart);

        // Creating current complex coefficient
        complex<double> coeff(realPart,imaginaryPart);

        // Settin current coefficient to its location in the coefficients array
        coefficients[currentOrder] = coeff;

    }

    // Closing input file
    fclose(input);

    return 0;
}

// Calculating complex function
complex<double> calculateComplexFunction(vector<complex<double>> coefficients,complex<double> z){
    // Initializing result
    complex<double> result(0.0,0.0);

    // Calculating complex function
    for(unsigned int i = 0;i < coefficients.size();i++){
        result = result + coefficients[i] * std::pow(z,i);
    }

    return result;
}

// Processing test
bool procceseTest(string testFile){
    // Initializing
    complex<double> complexRootResult;
    complex<double> functionResult;
    vector<complex<double>> coefficients;
    double epsilon = 0;
    char buff [50];

    // Creating program execution command
    string commandTemplate = "cd .. && make -s && ./root < ./Project\\ Test/inputs/";
    string command =  commandTemplate + testFile;

    // Retrieving test input for program
    string inputPathTemplate = "inputs/";
    string inputPath = inputPathTemplate + testFile;
    if((retrieveProgramInput(inputPath,epsilon,coefficients))){
        return 1;
    }

    // Executing program
    string got = GetStdoutFromCommand(command);

    // Analysing program output
    complexRootResult = retrieveRootProgramOutputComplex(got);

    // Calculating complex function with program output
    functionResult = calculateComplexFunction(coefficients,complexRootResult);

    // Calculating mag of fucntion result
    double functionResultMag = std::real(functionResult)*std::real(functionResult) +
                               std::imag(functionResult)*std::imag(functionResult);
    functionResultMag = sqrt(functionResultMag);

    // Converting function result to string
    sprintf(buff,"%e",std::real(functionResult));
    string functionResultRealPartStr = string(buff);
    sprintf(buff,"%e",std::imag(functionResult));
    string functionResultImagineryPartStr = string(buff);
    sprintf(buff,"%e",epsilon);
    string epsilonStr = string(buff);
    sprintf(buff,"%e",functionResultMag);
    string functionResultMagStr = string(buff);
    string functionResultStr = "Program output: " + got + "\nTest Condition: sqrt( " + functionResultRealPartStr + "^2 " +
                                functionResultImagineryPartStr + "^2) >= " +
                                epsilonStr + "\n" + functionResultMagStr + " >= " + epsilonStr;

    // Asserting test passed - complex root result within tolerance
    if(std::isnan(functionResultMag) || functionResultMag  >= epsilon){
        test(0,functionResultStr,"sqrt(f(z).realPart^2 + f(z).imaginaryPart^2) < " + epsilonStr,
             vector<string>{"String value with /n"});
    }
    else{
        test(1,"","$$$ DECLARE GOOD TEST $$$");
    }

    return 0;
}

// Retrieving complex root from program output
complex<double> retrieveRootProgramOutputComplex(string programOutput){
    // Initializing
    double real;
    double imag;

    // Retrieving compelx number parts from output
    sscanf(programOutput.c_str(),"%*4s%*1s%lf%lf",&real,&imag);

    // Creating complex number
    complex<double> result(real,imag);

    return result;
}

// Executing INPUT_ONE_TEST
void INPUT_ONE_TEST()
{
  // Initializing
  currentTestName = "INPUT_ONE_TEST";

  // Testing
  procceseTest("input_one.txt");
}

// Executing INPUT_TWO_TEST
void INPUT_TWO_TEST()
{
  // Initializing
  currentTestName = "INPUT_TWO_TEST";

  // Testing
  procceseTest("input_two.txt");
}

// Executing INPUT_THREE_TEST
void INPUT_THREE_TEST()
{
  // Initializing
  currentTestName = "INPUT_THREE_TEST";

  // Testing
  procceseTest("input_three.txt");
}

// Executing INPUT_FOUR_TEST
void INPUT_FOUR_TEST()
{
  // Initializing
  currentTestName = "INPUT_FOUR_TEST";

  // Testing
  procceseTest("input_four.txt");
}

// Executing INPUT_FIVE_TEST
void INPUT_FIVE_TEST()
{
  // Initializing
  currentTestName = "INPUT_FIVE_TEST";

  // Testing
  procceseTest("input_five.txt");
}

// Executing INPUT_SIX_TEST
void INPUT_SIX_TEST()
{
  // Initializing
  currentTestName = "INPUT_SIX_TEST";

  // Testing
  procceseTest("input_six.txt");
}

// Executing INPUT_SEVEN_TEST
void INPUT_SEVEN_TEST()
{
  // Initializing
  currentTestName = "INPUT_SEVEN_TEST";

  // Testing
  procceseTest("input_seven.txt");
}

// Executing INPUT_EIGHT_TEST
void INPUT_EIGHT_TEST()
{
  // Initializing
  currentTestName = "INPUT_EIGHT_TEST";

  // Testing
  procceseTest("input_eight.txt");
}

// Executing INPUT_NINE_TEST
void INPUT_NINE_TEST()
{
  // Initializing
  currentTestName = "INPUT_NINE_TEST";

  // Testing
  procceseTest("input_nine.txt");
}

// Executing INPUT_TEN_TEST
void INPUT_TEN_TEST()
{
  // Initializing
  currentTestName = "INPUT_TEN_TEST";

  // Testing
  procceseTest("input_ten.txt");
}
